package com.moidela.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class RepeatType { NONE, DAILY, WEEKDAYS, INTERVAL }

/** Дело. Все даты хранятся как epochDay (дни от 1970-01-01), чтобы не зависеть от часовых поясов. */
@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val startDay: Long,
    /** Последний день серии (включительно). Нужен при переносе повторяющегося дела. */
    val endDay: Long? = null,
    val timeMinutes: Int? = null,
    val repeatType: RepeatType = RepeatType.NONE,
    /** Битовая маска дней недели: бит 0 = понедельник ... бит 6 = воскресенье. */
    val weekdaysMask: Int = 0,
    val intervalDays: Int = 1,
    val sortOrder: Long = 0
)

/** Отметка «выполнено» для конкретного дела в конкретный день. */
@Entity(
    tableName = "completions",
    primaryKeys = ["taskId", "day"],
    foreignKeys = [ForeignKey(
        entity = TaskEntity::class,
        parentColumns = ["id"],
        childColumns = ["taskId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("taskId")]
)
data class CompletionEntity(val taskId: Long, val day: Long)

/** Период заморозки конкретного дела (включительно). */
@Entity(
    tableName = "freezes",
    foreignKeys = [ForeignKey(
        entity = TaskEntity::class,
        parentColumns = ["id"],
        childColumns = ["taskId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("taskId")]
)
data class FreezeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskId: Long,
    val startDay: Long,
    val endDay: Long
)
