package com.moidela.app.domain

import com.moidela.app.data.Snapshot
import java.time.LocalDateTime

object ReminderPlanner {
    /**
     * Ближайший момент напоминания строго после [after]: учитываются только дела со временем,
     * не выполненные и не замороженные в этот день.
     */
    fun next(snap: Snapshot, after: LocalDateTime, horizonDays: Int = 60): LocalDateTime? {
        val start = after.toLocalDate()
        for (i in 0..horizonDays) {
            val date = start.plusDays(i.toLong())
            val minute = Schedule.forDay(date.toEpochDay(), snap.tasks, snap.done, snap.freezes)
                .filter { !it.frozen && !it.done }
                .mapNotNull { it.task.timeMinutes }
                .filter { date.atTime(it / 60, it % 60).isAfter(after) }
                .minOrNull()
            if (minute != null) return date.atTime(minute / 60, minute % 60)
        }
        return null
    }
}
