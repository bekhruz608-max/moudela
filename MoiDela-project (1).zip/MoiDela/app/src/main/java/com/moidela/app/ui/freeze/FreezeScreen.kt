@file:OptIn(ExperimentalMaterial3Api::class)

package com.moidela.app.ui.freeze

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.moidela.app.data.FreezeEntity
import com.moidela.app.ui.DatePickerDialogRu
import com.moidela.app.ui.EmptyState
import com.moidela.app.ui.shortDate
import java.time.LocalDate

@Composable
fun FreezeScreen(vm: FreezeViewModel, onBack: () -> Unit) {
    val task by vm.task.collectAsStateWithLifecycle()
    val freezes by vm.freezes.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }
    val scheme = MaterialTheme.colorScheme
    val today = LocalDate.now().toEpochDay()

    var dialogOpen by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<FreezeEntity?>(null) }
    var toDelete by remember { mutableStateOf<FreezeEntity?>(null) }

    LaunchedEffect(vm.message) {
        vm.message?.let { snack.showSnackbar(it); vm.message = null }
    }

    Scaffold(
        containerColor = scheme.background,
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Заморозка")
                        task?.let {
                            Text(
                                it.title,
                                style = MaterialTheme.typography.bodySmall,
                                color = scheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
                    }
                }
            )
        },
        bottomBar = {
            Surface(color = scheme.background, modifier = Modifier.navigationBarsPadding()) {
                Button(
                    onClick = { editing = null; dialogOpen = true },
                    modifier = Modifier.fillMaxWidth().padding(16.dp).height(52.dp)
                ) { Text("Добавить период заморозки", style = MaterialTheme.typography.titleMedium) }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (freezes.isEmpty()) {
                EmptyState(
                    icon = Icons.Default.AcUnit,
                    title = "Периодов заморозки нет",
                    subtitle = "В заморозке дело не появляется в расписании, а потом возвращается само. Остальные дела это не затрагивает."
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(freezes, key = { it.id }) { f ->
                        val status = when {
                            today in f.startDay..f.endDay -> "Активна"
                            today < f.startDay -> "Запланирована"
                            else -> "Завершена"
                        }
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = MaterialTheme.shapes.large,
                            colors = CardDefaults.cardColors(containerColor = scheme.surfaceVariant)
                        ) {
                            Row(
                                Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        "${LocalDate.ofEpochDay(f.startDay).shortDate()} — ${LocalDate.ofEpochDay(f.endDay).shortDate()}",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        status,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (status == "Активна") scheme.primary else scheme.onSurfaceVariant
                                    )
                                }
                                IconButton(onClick = { editing = f; dialogOpen = true }) {
                                    Icon(Icons.Default.Edit, contentDescription = "Изменить")
                                }
                                IconButton(onClick = { toDelete = f }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Удалить", tint = scheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (dialogOpen) {
        FreezeDialog(
            initial = editing,
            onDismiss = { dialogOpen = false },
            onConfirm = { s, e -> vm.save(editing, s, e); dialogOpen = false }
        )
    }
    toDelete?.let { f ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Удалить период?") },
            text = { Text("Дело снова будет появляться в расписании в эти дни.") },
            confirmButton = {
                TextButton(onClick = { vm.delete(f.id); toDelete = null }) {
                    Text("Удалить", color = scheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Отмена") } }
        )
    }
}

@Composable
private fun FreezeDialog(
    initial: FreezeEntity?,
    onDismiss: () -> Unit,
    onConfirm: (LocalDate, LocalDate) -> Unit
) {
    var start by remember {
        mutableStateOf(initial?.let { LocalDate.ofEpochDay(it.startDay) } ?: LocalDate.now())
    }
    var end by remember {
        mutableStateOf(initial?.let { LocalDate.ofEpochDay(it.endDay) } ?: LocalDate.now().plusDays(6))
    }
    var picking by remember { mutableIntStateOf(0) } // 0 — нет, 1 — начало, 2 — конец

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Новый период заморозки" else "Изменить период") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { picking = 1 }, modifier = Modifier.fillMaxWidth()) {
                    Text("Начало: ${start.shortDate()}")
                }
                OutlinedButton(onClick = { picking = 2 }, modifier = Modifier.fillMaxWidth()) {
                    Text("Конец: ${end.shortDate()}")
                }
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(start, end) }) { Text("Сохранить") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )

    if (picking == 1) {
        DatePickerDialogRu(start, { picking = 0 }) {
            start = it
            if (end.isBefore(start)) end = start
            picking = 0
        }
    }
    if (picking == 2) {
        DatePickerDialogRu(end, { picking = 0 }) {
            end = it
            if (end.isBefore(start)) start = end
            picking = 0
        }
    }
}
