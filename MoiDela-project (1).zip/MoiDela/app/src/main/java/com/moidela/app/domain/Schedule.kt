package com.moidela.app.domain

import com.moidela.app.data.FreezeEntity
import com.moidela.app.data.TaskEntity
import java.time.DayOfWeek
import java.time.LocalDate

data class DayItem(val task: TaskEntity, val done: Boolean, val freezeEnd: Long?) {
    val frozen: Boolean get() = freezeEnd != null
}

object Schedule {

    fun forDay(
        day: Long,
        tasks: List<TaskEntity>,
        done: Set<Pair<Long, Long>>,
        freezes: List<FreezeEntity>
    ): List<DayItem> =
        tasks.filter { Recurrence.occursOn(it, day) }
            .map { DayItem(it, (it.id to day) in done, Recurrence.freezeEnd(freezes, it.id, day)) }

    /** Семь дней недели, содержащей [date], начиная с [firstDay]. */
    fun weekOf(date: LocalDate, firstDay: DayOfWeek): List<LocalDate> {
        val diff = (date.dayOfWeek.value - firstDay.value + 7) % 7
        val start = date.minusDays(diff.toLong())
        return (0..6).map { start.plusDays(it.toLong()) }
    }
}
