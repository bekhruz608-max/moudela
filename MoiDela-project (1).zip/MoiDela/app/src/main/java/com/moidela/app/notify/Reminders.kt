package com.moidela.app.notify

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.moidela.app.MainActivity
import com.moidela.app.MoiDelaApp
import com.moidela.app.R
import com.moidela.app.data.AppSettings
import com.moidela.app.data.Snapshot
import com.moidela.app.data.TaskEntity
import com.moidela.app.domain.ReminderPlanner
import com.moidela.app.domain.Schedule
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

object Reminders {
    const val CHANNEL = "reminders"
    const val ACTION_FIRE = "com.moidela.app.REMINDER_FIRE"
    const val ACTION_DONE = "com.moidela.app.REMINDER_DONE"
    private const val PREFS = "reminders"
    private const val LAST = "last"

    private val mutex = Mutex()

    fun ensureChannel(ctx: Context) {
        val channel = NotificationChannel(
            CHANNEL, "Напоминания о делах", NotificationManager.IMPORTANCE_HIGH
        ).apply { description = "Уведомления в назначенное время дела" }
        ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun key(date: LocalDate, minutes: Int): Long = date.toEpochDay() * 1440 + minutes

    private fun nowKey(now: LocalDateTime): Long = key(now.toLocalDate(), now.hour * 60 + now.minute)

    private fun firePending(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, 0,
            Intent(ctx, ReminderReceiver::class.java).setAction(ACTION_FIRE),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    /** Ставит один будильник на ближайшее напоминание (после срабатывания ставится следующий). */
    fun schedule(ctx: Context, snap: Snapshot, st: AppSettings) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = firePending(ctx)
        am.cancel(pi)
        if (!st.remindersEnabled) return
        val next = ReminderPlanner.next(snap, LocalDateTime.now()) ?: return
        val at = next.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        try {
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    /** Показывает напоминания, время которых наступило с момента прошлой проверки (но не старше 3 часов). */
    suspend fun deliverDue(ctx: Context, snap: Snapshot, st: AppSettings) = mutex.withLock {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = LocalDateTime.now()
        val today = now.toLocalDate()
        val nowKey = nowKey(now)
        val last = prefs.getLong(LAST, 0L)
        prefs.edit().putLong(LAST, nowKey).apply()
        if (!st.remindersEnabled) return@withLock
        val from = maxOf(last, nowKey - 180)
        Schedule.forDay(today.toEpochDay(), snap.tasks, snap.done, snap.freezes)
            .filter { !it.frozen && !it.done }
            .forEach { item ->
                val minutes = item.task.timeMinutes ?: return@forEach
                if (key(today, minutes) in (from + 1)..nowKey) show(ctx, item.task, today.toEpochDay())
            }
    }

    /** Данные изменились во время работы приложения: прошедшие по времени дела уведомлять не нужно. */
    suspend fun markNow(ctx: Context) = mutex.withLock {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val k = nowKey(LocalDateTime.now())
        if (k > prefs.getLong(LAST, 0L)) prefs.edit().putLong(LAST, k).apply()
    }

    @SuppressLint("MissingPermission")
    private fun show(ctx: Context, task: TaskEntity, day: Long) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return
        val id = task.id.toInt()
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val open = PendingIntent.getActivity(
            ctx, id,
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            flags
        )
        val done = PendingIntent.getBroadcast(
            ctx, id,
            Intent(ctx, ReminderReceiver::class.java)
                .setAction(ACTION_DONE)
                .putExtra("taskId", task.id)
                .putExtra("day", day),
            flags
        )
        val text = task.description.ifBlank { "Пора выполнить дело" }
        val notification = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(task.title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
            .addAction(0, "Выполнено", done)
            .build()
        NotificationManagerCompat.from(ctx).notify(id, notification)
    }
}

/** Срабатывание будильника и кнопка «Выполнено» в уведомлении. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext as MoiDelaApp
        val pending = goAsync()
        app.appScope.launch {
            try {
                when (intent.action) {
                    Reminders.ACTION_DONE -> {
                        val id = intent.getLongExtra("taskId", 0L)
                        val day = intent.getLongExtra("day", 0L)
                        if (id != 0L) {
                            app.repository.setDone(id, day, true)
                            NotificationManagerCompat.from(app).cancel(id.toInt())
                        }
                    }
                    else -> {
                        val snap = app.repository.snapshot.first()
                        val st = app.settings.settings.first()
                        Reminders.deliverDue(app, snap, st)
                        Reminders.schedule(app, snap, st)
                    }
                }
            } finally {
                pending.finish()
            }
        }
    }
}

/**
 * Перезагрузка, смена времени/часового пояса, обновление приложения. Сам приёмник пустой:
 * запуск процесса вызывает MoiDelaApp.onCreate, который заново ставит будильник.
 */
class SystemEventsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) = Unit
}
