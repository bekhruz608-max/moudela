package com.moidela.app.ui.freeze

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.moidela.app.data.FreezeEntity
import com.moidela.app.data.TaskEntity
import com.moidela.app.data.TaskRepository
import java.time.LocalDate
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class FreezeViewModel(private val repo: TaskRepository, private val taskId: Long) : ViewModel() {

    val task: StateFlow<TaskEntity?> = repo.tasks
        .map { list -> list.firstOrNull { it.id == taskId } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val freezes: StateFlow<List<FreezeEntity>> = repo.freezes
        .map { list -> list.filter { it.taskId == taskId } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    var message by mutableStateOf<String?>(null)

    private fun launchSafe(block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = "Не удалось сохранить изменения"
            }
        }
    }

    /** [existing] == null — добавление нового периода, иначе изменение. */
    fun save(existing: FreezeEntity?, start: LocalDate, end: LocalDate) {
        if (end.isBefore(start)) {
            message = "Конец периода не может быть раньше начала"
            return
        }
        launchSafe {
            if (existing == null) repo.addFreeze(taskId, start.toEpochDay(), end.toEpochDay())
            else repo.updateFreeze(existing.copy(startDay = start.toEpochDay(), endDay = end.toEpochDay()))
        }
    }

    fun delete(id: Long) = launchSafe { repo.deleteFreeze(id) }
}
