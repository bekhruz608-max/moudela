package com.moidela.app.ui.edit

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.moidela.app.data.RepeatType
import com.moidela.app.data.TaskEntity
import com.moidela.app.data.TaskRepository
import java.time.LocalDate
import java.time.LocalTime
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class EditViewModel(
    private val repo: TaskRepository,
    private val taskId: Long,
    defaultDay: Long
) : ViewModel() {

    val isNew = taskId == 0L

    var title by mutableStateOf("")
    var description by mutableStateOf("")
    var date by mutableStateOf(LocalDate.ofEpochDay(defaultDay))
    var time by mutableStateOf<LocalTime?>(null)
    var repeat by mutableStateOf(RepeatType.NONE)
    var mask by mutableIntStateOf(0)
    var interval by mutableStateOf("2")

    var loading by mutableStateOf(!isNew)
    var notFound by mutableStateOf(false)
    var saving by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)

    private var original: TaskEntity? = null

    init {
        if (!isNew) {
            viewModelScope.launch {
                val t = repo.getTask(taskId)
                if (t == null) {
                    notFound = true
                } else {
                    original = t
                    title = t.title
                    description = t.description
                    date = LocalDate.ofEpochDay(t.startDay)
                    time = t.timeMinutes?.let { LocalTime.of(it / 60, it % 60) }
                    repeat = t.repeatType
                    mask = t.weekdaysMask
                    interval = t.intervalDays.toString()
                }
                loading = false
            }
        }
    }

    fun setRepeat(type: RepeatType) {
        repeat = type
        error = null
        if (type == RepeatType.WEEKDAYS && mask == 0) {
            mask = 1 shl (date.dayOfWeek.value - 1)
        }
    }

    fun toggleDay(index: Int) {
        mask = mask xor (1 shl index)
        error = null
    }

    fun save(onDone: () -> Unit) {
        if (saving) return
        val name = title.trim()
        if (name.isEmpty()) { error = "Введите название дела"; return }
        if (repeat == RepeatType.WEEKDAYS && mask == 0) {
            error = "Выберите хотя бы один день недели"; return
        }
        var days = 1
        if (repeat == RepeatType.INTERVAL) {
            days = interval.trim().toIntOrNull() ?: 0
            if (days !in 1..365) { error = "Укажите число дней от 1 до 365"; return }
        }
        val base = original
        val task = TaskEntity(
            id = taskId,
            title = name,
            description = description.trim(),
            startDay = date.toEpochDay(),
            endDay = base?.endDay,
            timeMinutes = time?.let { it.hour * 60 + it.minute },
            repeatType = repeat,
            weekdaysMask = if (repeat == RepeatType.WEEKDAYS) mask else 0,
            intervalDays = days,
            sortOrder = base?.sortOrder ?: 0
        )
        saving = true
        viewModelScope.launch {
            try {
                if (isNew) {
                    val duplicate = repo.tasks.first().any {
                        it.title.equals(task.title, ignoreCase = true) &&
                            it.startDay == task.startDay &&
                            it.timeMinutes == task.timeMinutes &&
                            it.repeatType == task.repeatType &&
                            it.weekdaysMask == task.weekdaysMask &&
                            it.intervalDays == task.intervalDays
                    }
                    if (duplicate) {
                        error = "Такое дело уже существует"
                        saving = false
                        return@launch
                    }
                }
                repo.save(task)
                onDone()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = "Не удалось сохранить дело"
                saving = false
            }
        }
    }

    fun delete(onDone: () -> Unit) {
        if (isNew || saving) return
        saving = true
        viewModelScope.launch {
            try {
                repo.delete(taskId)
                onDone()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = "Не удалось удалить дело"
                saving = false
            }
        }
    }
}
