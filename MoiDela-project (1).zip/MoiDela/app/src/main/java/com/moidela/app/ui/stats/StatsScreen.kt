@file:OptIn(ExperimentalMaterial3Api::class)

package com.moidela.app.ui.stats

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.moidela.app.data.SettingsRepository
import com.moidela.app.data.TaskRepository
import com.moidela.app.domain.Schedule
import com.moidela.app.ui.dayMonth
import com.moidela.app.ui.dayShort
import java.time.LocalDate
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class DayStat(val date: LocalDate, val total: Int, val done: Int)

data class StatsState(
    val today: DayStat = DayStat(LocalDate.now(), 0, 0),
    val week: List<DayStat> = emptyList(),
    val weekOffset: Int = 0
) {
    val weekTotal get() = week.sumOf { it.total }
    val weekDone get() = week.sumOf { it.done }
}

class StatsViewModel(repo: TaskRepository, settings: SettingsRepository) : ViewModel() {
    private val offset = MutableStateFlow(0)

    val state: StateFlow<StatsState> = combine(repo.snapshot, settings.settings, offset) { snap, st, off ->
        fun stat(d: LocalDate): DayStat {
            val items = Schedule.forDay(d.toEpochDay(), snap.tasks, snap.done, snap.freezes)
                .filter { !it.frozen }
            return DayStat(d, items.size, items.count { it.done })
        }
        val anchor = LocalDate.now().plusWeeks(off.toLong())
        StatsState(
            today = stat(LocalDate.now()),
            week = Schedule.weekOf(anchor, st.firstDay).map(::stat),
            weekOffset = off
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), StatsState())

    fun shiftWeek(delta: Int) { offset.value += delta }
    fun reset() { offset.value = 0 }
}

@Composable
fun StatsScreen(vm: StatsViewModel) {
    val s by vm.state.collectAsStateWithLifecycle()
    val scheme = MaterialTheme.colorScheme

    Scaffold(
        containerColor = scheme.background,
        topBar = { TopAppBar(title = { Text("Статистика") }) }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SummaryCard("Сегодня", s.today.done, s.today.total)

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { vm.shiftWeek(-1) }) { Icon(Icons.Default.ChevronLeft, "Предыдущая неделя") }
                val first = s.week.firstOrNull()?.date
                val last = s.week.lastOrNull()?.date
                Text(
                    if (first != null && last != null) "${first.dayMonth()} — ${last.dayMonth()}" else "",
                    Modifier.weight(1f),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                IconButton(onClick = { vm.shiftWeek(1) }) { Icon(Icons.Default.ChevronRight, "Следующая неделя") }
            }

            SummaryCard("Неделя", s.weekDone, s.weekTotal)

            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = scheme.surfaceVariant)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("По дням", style = MaterialTheme.typography.titleSmall)
                    s.week.forEach { d ->
                        val p = if (d.total == 0) 0f else d.done / d.total.toFloat()
                        val anim by animateFloatAsState(p, tween(500), label = "bar")
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "${dayShort(d.date.dayOfWeek)} ${d.date.dayOfMonth}",
                                Modifier.width(56.dp),
                                style = MaterialTheme.typography.labelLarge
                            )
                            LinearProgressIndicator(
                                progress = { anim },
                                modifier = Modifier.weight(1f).height(8.dp).clip(CircleShape),
                                color = scheme.primary,
                                trackColor = scheme.outlineVariant
                            )
                            Text(
                                "${d.done}/${d.total}",
                                Modifier.width(48.dp).padding(start = 8.dp),
                                style = MaterialTheme.typography.labelLarge,
                                color = scheme.onSurfaceVariant
                            )
                        }
                    }
                    Text(
                        "Замороженные дела в статистику не входят.",
                        style = MaterialTheme.typography.bodySmall,
                        color = scheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun SummaryCard(title: String, done: Int, total: Int) {
    val scheme = MaterialTheme.colorScheme
    val p = if (total == 0) 0f else done / total.toFloat()
    val anim by animateFloatAsState(p, tween(600), label = "ring")
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = scheme.surfaceVariant)
    ) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(84.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = { anim },
                    modifier = Modifier.fillMaxSize(),
                    strokeWidth = 9.dp,
                    color = scheme.primary,
                    trackColor = scheme.outlineVariant,
                    strokeCap = StrokeCap.Round
                )
                Text("${(p * 100).toInt()}%", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.padding(start = 20.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    if (total == 0) "Дел не запланировано" else "Выполнено $done из $total",
                    style = MaterialTheme.typography.bodyMedium,
                    color = scheme.onSurfaceVariant
                )
            }
        }
    }
}
