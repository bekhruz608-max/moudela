@file:OptIn(ExperimentalMaterial3Api::class)

package com.moidela.app.ui.main

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.moidela.app.data.TaskEntity
import com.moidela.app.domain.DayItem
import com.moidela.app.ui.EmptyState
import com.moidela.app.ui.dayMonth
import com.moidela.app.ui.dayShort
import com.moidela.app.ui.formatMinutes
import com.moidela.app.ui.fullTitle
import com.moidela.app.ui.pressClickable
import com.moidela.app.ui.repeatSummary
import java.time.LocalDate

@Composable
fun MainScreen(
    vm: MainViewModel,
    onAdd: (epochDay: Long) -> Unit,
    onEdit: (taskId: Long) -> Unit,
    onFreeze: (taskId: Long) -> Unit
) {
    val s by vm.state.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }
    var toDelete by remember { mutableStateOf<TaskEntity?>(null) }
    val today = LocalDate.now()

    LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it) } }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snack) },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { onAdd(s.day.toEpochDay()) },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) { Icon(Icons.Default.Add, contentDescription = "Добавить дело") }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            // Заголовок
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "Мои дела",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        s.day.fullTitle(),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
                if (s.day != today) {
                    FilledTonalButton(onClick = vm::goToday) { Text("Сегодня") }
                }
            }

            // Неделя
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.shiftWeek(-1) }, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.ChevronLeft, contentDescription = "Предыдущая неделя")
                }
                s.weekDays.forEach { d ->
                    DayCell(
                        date = d,
                        selected = d == s.day,
                        isToday = d == today,
                        modifier = Modifier.weight(1f),
                        onClick = { vm.selectDay(d) }
                    )
                }
                IconButton(onClick = { vm.shiftWeek(1) }, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.ChevronRight, contentDescription = "Следующая неделя")
                }
            }

            // Прогресс
            val progress = if (s.total == 0) 0f else s.done / s.total.toFloat()
            val animated by animateFloatAsState(progress, tween(500), label = "progress")
            Card(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "Прогресс дня",
                            Modifier.weight(1f),
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            "${s.done} из ${s.total}",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = { animated },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.outlineVariant
                    )
                }
            }

            // Фильтры
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TaskFilter.entries.forEach { f ->
                    FilterChip(
                        selected = s.filter == f,
                        onClick = { vm.setFilter(f) },
                        label = { Text(f.label) }
                    )
                }
            }

            // Список
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (s.items.isEmpty()) {
                    if (s.total == 0 && s.frozenCount == 0) {
                        EmptyState(
                            icon = Icons.Default.EventAvailable,
                            title = "На этот день дел нет",
                            subtitle = "Запланируйте что-нибудь — начните с первого дела.",
                            actionLabel = "Добавить первое дело",
                            onAction = { onAdd(s.day.toEpochDay()) }
                        )
                    } else {
                        EmptyState(
                            icon = Icons.Default.FilterList,
                            title = "Здесь пока пусто",
                            subtitle = "По выбранному фильтру ничего не найдено. Смените фильтр или день."
                        )
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        itemsIndexed(s.items, key = { _, row -> row.task.id }) { index, item ->
                            TaskCard(
                                item = item,
                                modifier = Modifier.animateItem(),
                                canUp = index > 0,
                                canDown = index < s.items.lastIndex,
                                onToggle = { vm.toggle(item) },
                                onOpen = { onEdit(item.task.id) },
                                onMoveTomorrow = { vm.moveToTomorrow(item) },
                                onFreeze = { onFreeze(item.task.id) },
                                onDelete = { toDelete = item.task },
                                onUp = { vm.move(item.task.id, true) },
                                onDown = { vm.move(item.task.id, false) }
                            )
                        }
                    }
                }
            }
        }
    }

    toDelete?.let { t ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Удалить дело?") },
            text = { Text("«${t.title}» будет удалено вместе с отметками выполнения и периодами заморозки.") },
            confirmButton = {
                TextButton(onClick = { vm.delete(t.id); toDelete = null }) {
                    Text("Удалить", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Отмена") } }
        )
    }
}

@Composable
private fun DayCell(
    date: LocalDate,
    selected: Boolean,
    isToday: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val scheme = MaterialTheme.colorScheme
    val bg by animateColorAsState(
        when {
            selected -> scheme.primary
            isToday -> scheme.primaryContainer
            else -> Color.Transparent
        },
        label = "dayBg"
    )
    val fg = if (selected) scheme.onPrimary else scheme.onSurface
    Column(
        modifier = modifier
            .padding(2.dp)
            .pressClickable(onClick)
            .clip(RoundedCornerShape(14.dp))
            .background(bg)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(dayShort(date.dayOfWeek), style = MaterialTheme.typography.labelSmall, color = fg.copy(alpha = 0.8f))
        Text(
            date.dayOfMonth.toString(),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = fg
        )
    }
}

@Composable
private fun TaskCard(
    item: DayItem,
    modifier: Modifier,
    canUp: Boolean,
    canDown: Boolean,
    onToggle: () -> Unit,
    onOpen: () -> Unit,
    onMoveTomorrow: () -> Unit,
    onFreeze: () -> Unit,
    onDelete: () -> Unit,
    onUp: () -> Unit,
    onDown: () -> Unit
) {
    val scheme = MaterialTheme.colorScheme
    val task = item.task
    var menu by remember { mutableStateOf(false) }
    val fill by animateColorAsState(if (item.done) scheme.primary else Color.Transparent, label = "fill")

    Card(
        modifier = modifier.fillMaxWidth().pressClickable(onOpen),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = scheme.surfaceVariant)
    ) {
        Row(
            Modifier.padding(start = 6.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (item.frozen) {
                Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.AcUnit, contentDescription = "Заморожено", tint = scheme.primary)
                }
            } else {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).clickable(onClick = onToggle),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(fill)
                            .border(2.dp, if (item.done) scheme.primary else scheme.outline, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        if (item.done) {
                            Icon(
                                Icons.Default.Check,
                                contentDescription = "Выполнено",
                                tint = scheme.onPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            Column(Modifier.weight(1f).padding(horizontal = 6.dp)) {
                Text(
                    task.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    textDecoration = if (item.done) TextDecoration.LineThrough else null,
                    color = if (item.done || item.frozen) scheme.onSurface.copy(alpha = 0.55f) else scheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                if (task.description.isNotBlank()) {
                    Text(
                        task.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = scheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                val meta = listOfNotNull(
                    task.timeMinutes?.let { formatMinutes(it) },
                    repeatSummary(task),
                    item.freezeEnd?.let { "Заморожено до ${LocalDate.ofEpochDay(it).dayMonth()}" }
                ).joinToString(" · ")
                if (meta.isNotEmpty()) {
                    Text(meta, style = MaterialTheme.typography.labelMedium, color = scheme.primary)
                }
            }

            Box {
                IconButton(onClick = { menu = true }) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Действия")
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Редактировать") },
                        leadingIcon = { Icon(Icons.Default.Edit, null) },
                        onClick = { menu = false; onOpen() }
                    )
                    if (!item.frozen && !item.done) {
                        DropdownMenuItem(
                            text = { Text("Перенести на завтра") },
                            leadingIcon = { Icon(Icons.AutoMirrored.Filled.ArrowForward, null) },
                            onClick = { menu = false; onMoveTomorrow() }
                        )
                    }
                    DropdownMenuItem(
                        text = { Text(if (item.frozen) "Периоды заморозки" else "Заморозить") },
                        leadingIcon = { Icon(Icons.Default.AcUnit, null) },
                        onClick = { menu = false; onFreeze() }
                    )
                    if (canUp) {
                        DropdownMenuItem(
                            text = { Text("Выше") },
                            leadingIcon = { Icon(Icons.Default.ArrowUpward, null) },
                            onClick = { menu = false; onUp() }
                        )
                    }
                    if (canDown) {
                        DropdownMenuItem(
                            text = { Text("Ниже") },
                            leadingIcon = { Icon(Icons.Default.ArrowDownward, null) },
                            onClick = { menu = false; onDown() }
                        )
                    }
                    HorizontalDivider()
                    DropdownMenuItem(
                        text = { Text("Удалить", color = scheme.error) },
                        leadingIcon = { Icon(Icons.Default.Delete, null, tint = scheme.error) },
                        onClick = { menu = false; onDelete() }
                    )
                }
            }
        }
    }
}
