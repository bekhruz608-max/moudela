@file:OptIn(ExperimentalMaterial3Api::class)

package com.moidela.app.ui.search

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.moidela.app.data.TaskEntity
import com.moidela.app.data.TaskRepository
import com.moidela.app.domain.Recurrence
import com.moidela.app.ui.EmptyState
import com.moidela.app.ui.formatMinutes
import com.moidela.app.ui.pressClickable
import com.moidela.app.ui.repeatSummary
import com.moidela.app.ui.shortDate
import java.time.LocalDate
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

class SearchViewModel(repo: TaskRepository) : ViewModel() {
    val query = MutableStateFlow("")

    val results: StateFlow<List<Pair<TaskEntity, Boolean>>> = combine(repo.tasks, repo.freezes, query) { tasks, freezes, q ->
        val needle = q.trim().lowercase()
        val today = LocalDate.now().toEpochDay()
        if (needle.isEmpty()) emptyList()
        else tasks
            .filter { it.title.lowercase().contains(needle) || it.description.lowercase().contains(needle) }
            .map { it to Recurrence.isFrozen(freezes, it.id, today) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}

@Composable
fun SearchScreen(vm: SearchViewModel, onOpen: (Long) -> Unit) {
    val q by vm.query.collectAsStateWithLifecycle()
    val results by vm.results.collectAsStateWithLifecycle()
    val scheme = MaterialTheme.colorScheme

    Scaffold(
        containerColor = scheme.background,
        topBar = { TopAppBar(title = { Text("Поиск дел") }) }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            OutlinedTextField(
                value = q,
                onValueChange = { vm.query.value = it },
                placeholder = { Text("Название или описание") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = {
                    if (q.isNotEmpty()) {
                        IconButton(onClick = { vm.query.value = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Очистить")
                        }
                    }
                },
                singleLine = true,
                shape = MaterialTheme.shapes.large,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            )
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when {
                    q.isBlank() -> EmptyState(
                        icon = Icons.Default.Search,
                        title = "Найдите любое дело",
                        subtitle = "Поиск идёт по всем делам — и прошлым, и будущим."
                    )
                    results.isEmpty() -> EmptyState(
                        icon = Icons.Default.SearchOff,
                        title = "Ничего не найдено",
                        subtitle = "Попробуйте изменить запрос."
                    )
                    else -> LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(results, key = { it.first.id }) { (t, frozen) ->
                            Card(
                                modifier = Modifier.fillMaxWidth().pressClickable { onOpen(t.id) },
                                shape = MaterialTheme.shapes.large,
                                colors = CardDefaults.cardColors(containerColor = scheme.surfaceVariant)
                            ) {
                                Column(Modifier.padding(16.dp)) {
                                    Text(
                                        t.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (t.description.isNotBlank()) {
                                        Text(
                                            t.description,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = scheme.onSurfaceVariant,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    val meta = listOfNotNull(
                                        "с ${LocalDate.ofEpochDay(t.startDay).shortDate()}",
                                        t.timeMinutes?.let { formatMinutes(it) },
                                        repeatSummary(t),
                                        if (frozen) "заморожено сейчас" else null
                                    ).joinToString(" · ")
                                    Text(meta, style = MaterialTheme.typography.labelMedium, color = scheme.primary)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
