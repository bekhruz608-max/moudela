package com.moidela.app.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY sortOrder, id")
    fun observeTasks(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM completions")
    fun observeCompletions(): Flow<List<CompletionEntity>>

    @Query("SELECT * FROM freezes ORDER BY startDay")
    fun observeFreezes(): Flow<List<FreezeEntity>>

    @Query("SELECT * FROM tasks WHERE id = :id")
    suspend fun getTask(id: Long): TaskEntity?

    @Query("SELECT * FROM freezes WHERE taskId = :taskId")
    suspend fun getFreezesFor(taskId: Long): List<FreezeEntity>

    @Query("SELECT COALESCE(MAX(sortOrder), 0) FROM tasks")
    suspend fun maxSort(): Long

    @Query("SELECT COUNT(*) FROM completions WHERE taskId = :taskId AND day = :day")
    suspend fun doneCount(taskId: Long, day: Long): Int

    @Insert
    suspend fun insertTask(task: TaskEntity): Long

    @Update
    suspend fun updateTask(task: TaskEntity)

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun deleteTask(id: Long)

    @Query("UPDATE tasks SET sortOrder = :sort WHERE id = :id")
    suspend fun setSort(id: Long, sort: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCompletion(completion: CompletionEntity)

    @Query("DELETE FROM completions WHERE taskId = :taskId AND day = :day")
    suspend fun deleteCompletion(taskId: Long, day: Long)

    @Insert
    suspend fun insertFreeze(freeze: FreezeEntity): Long

    @Update
    suspend fun updateFreeze(freeze: FreezeEntity)

    @Query("DELETE FROM freezes WHERE id = :id")
    suspend fun deleteFreeze(id: Long)
}

@Database(
    entities = [TaskEntity::class, CompletionEntity::class, FreezeEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
}
