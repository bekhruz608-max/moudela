package com.moidela.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.moidela.app.data.AppSettings
import com.moidela.app.ui.edit.EditScreen
import com.moidela.app.ui.edit.EditViewModel
import com.moidela.app.ui.freeze.FreezeScreen
import com.moidela.app.ui.freeze.FreezeViewModel
import com.moidela.app.ui.main.MainScreen
import com.moidela.app.ui.main.MainViewModel
import com.moidela.app.ui.search.SearchScreen
import com.moidela.app.ui.search.SearchViewModel
import com.moidela.app.ui.settings.SettingsScreen
import com.moidela.app.ui.settings.SettingsViewModel
import com.moidela.app.ui.stats.StatsScreen
import com.moidela.app.ui.stats.StatsViewModel
import com.moidela.app.ui.theme.MoiDelaTheme
import java.time.LocalDate

class MainActivity : ComponentActivity() {
    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        requestNotificationPermissionOnce()
        val app = application as MoiDelaApp
        setContent {
            val settings by app.settings.settings.collectAsStateWithLifecycle(initialValue = AppSettings())
            MoiDelaTheme(settings.theme) { AppRoot(app) }
        }
    }

    private fun requestNotificationPermissionOnce() {
        if (Build.VERSION.SDK_INT < 33) return
        val granted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
        val prefs = getSharedPreferences("app", MODE_PRIVATE)
        if (!granted && !prefs.getBoolean("asked_notifications", false)) {
            prefs.edit().putBoolean("asked_notifications", true).apply()
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("main", "Дела", Icons.Default.TaskAlt),
    Tab("search", "Поиск", Icons.Default.Search),
    Tab("stats", "Статистика", Icons.Default.BarChart),
    Tab("settings", "Настройки", Icons.Default.Settings)
)

@Composable
private fun AppRoot(app: MoiDelaApp) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val showBar = tabs.any { it.route == route }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (showBar) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    tabs.forEach { tab ->
                        NavigationBarItem(
                            selected = route == tab.route,
                            onClick = {
                                nav.navigate(tab.route) {
                                    popUpTo("main") { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = null) },
                            label = { Text(tab.label) }
                        )
                    }
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = "main", modifier = Modifier.padding(pad)) {
            composable("main") {
                val vm: MainViewModel = viewModel(
                    factory = viewModelFactory { initializer { MainViewModel(app.repository, app.settings) } }
                )
                MainScreen(
                    vm,
                    onAdd = { day -> nav.navigate("edit/0/$day") },
                    onEdit = { id -> nav.navigate("edit/$id/0") },
                    onFreeze = { id -> nav.navigate("freeze/$id") }
                )
            }
            composable("search") {
                val vm: SearchViewModel = viewModel(
                    factory = viewModelFactory { initializer { SearchViewModel(app.repository) } }
                )
                SearchScreen(vm, onOpen = { id -> nav.navigate("edit/$id/0") })
            }
            composable("stats") {
                val vm: StatsViewModel = viewModel(
                    factory = viewModelFactory { initializer { StatsViewModel(app.repository, app.settings) } }
                )
                StatsScreen(vm)
            }
            composable("settings") {
                val vm: SettingsViewModel = viewModel(
                    factory = viewModelFactory { initializer { SettingsViewModel(app.settings) } }
                )
                SettingsScreen(vm)
            }
            composable(
                "edit/{id}/{day}",
                arguments = listOf(
                    navArgument("id") { type = NavType.LongType },
                    navArgument("day") { type = NavType.LongType }
                )
            ) { entry ->
                val id = entry.arguments?.getLong("id") ?: 0L
                val day = entry.arguments?.getLong("day") ?: LocalDate.now().toEpochDay()
                val vm: EditViewModel = viewModel(
                    factory = viewModelFactory { initializer { EditViewModel(app.repository, id, day) } }
                )
                EditScreen(
                    vm,
                    onBack = { nav.popBackStack() },
                    onFreeze = { nav.navigate("freeze/$id") }
                )
            }
            composable(
                "freeze/{id}",
                arguments = listOf(navArgument("id") { type = NavType.LongType })
            ) { entry ->
                val id = entry.arguments?.getLong("id") ?: 0L
                val vm: FreezeViewModel = viewModel(
                    factory = viewModelFactory { initializer { FreezeViewModel(app.repository, id) } }
                )
                FreezeScreen(vm, onBack = { nav.popBackStack() })
            }
        }
    }
}
