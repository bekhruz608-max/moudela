package com.moidela.app.domain

import com.moidela.app.data.FreezeEntity
import com.moidela.app.data.RepeatType
import com.moidela.app.data.TaskEntity
import java.time.LocalDate

object Recurrence {

    /** Попадает ли дело в расписание на день [day] (epochDay) без учёта заморозки. */
    fun occursOn(t: TaskEntity, day: Long): Boolean {
        if (day < t.startDay) return false
        val end = t.endDay
        if (end != null && day > end) return false
        return when (t.repeatType) {
            RepeatType.NONE -> day == t.startDay
            RepeatType.DAILY -> true
            RepeatType.WEEKDAYS -> {
                val bit = LocalDate.ofEpochDay(day).dayOfWeek.value - 1
                ((t.weekdaysMask shr bit) and 1) == 1
            }
            RepeatType.INTERVAL -> (day - t.startDay) % maxOf(1, t.intervalDays) == 0L
        }
    }

    /** Конец активного периода заморозки, покрывающего [day], либо null, если дело не заморожено. */
    fun freezeEnd(freezes: List<FreezeEntity>, taskId: Long, day: Long): Long? =
        freezes.filter { it.taskId == taskId && day >= it.startDay && day <= it.endDay }
            .maxOfOrNull { it.endDay }

    fun isFrozen(freezes: List<FreezeEntity>, taskId: Long, day: Long): Boolean =
        freezeEnd(freezes, taskId, day) != null

    /** Сдвиг маски дней недели на один день вперёд (пн→вт, ..., вс→пн). */
    fun rotateMask(mask: Int): Int = ((mask shl 1) or (mask shr 6)) and 0x7F
}
