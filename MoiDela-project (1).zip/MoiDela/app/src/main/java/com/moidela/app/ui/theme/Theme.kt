package com.moidela.app.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.moidela.app.data.ThemeMode

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8E7CFF),
    onPrimary = Color(0xFF12102A),
    primaryContainer = Color(0xFF2E2863),
    onPrimaryContainer = Color(0xFFE4DFFF),
    secondaryContainer = Color(0xFF2E2863),
    onSecondaryContainer = Color(0xFFE4DFFF),
    background = Color(0xFF0E0E12),
    onBackground = Color(0xFFEAEAF0),
    surface = Color(0xFF14141A),
    onSurface = Color(0xFFEAEAF0),
    surfaceVariant = Color(0xFF1F1F28),
    onSurfaceVariant = Color(0xFFA9A9B8),
    outline = Color(0xFF3A3A47),
    outlineVariant = Color(0xFF2A2A35),
    error = Color(0xFFFF6B7A)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF5B4BDB),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE4DFFF),
    onPrimaryContainer = Color(0xFF1A1450),
    secondaryContainer = Color(0xFFE4DFFF),
    onSecondaryContainer = Color(0xFF1A1450),
    background = Color(0xFFF7F6FB),
    onBackground = Color(0xFF16161C),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF16161C),
    surfaceVariant = Color(0xFFEDEBF6),
    onSurfaceVariant = Color(0xFF5E5E70),
    outline = Color(0xFFB9B7C9),
    outlineVariant = Color(0xFFD9D7E6),
    error = Color(0xFFC8374A)
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun MoiDelaTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        shapes = AppShapes,
        content = content
    )
}
