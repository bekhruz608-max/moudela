package com.moidela.app.ui

import com.moidela.app.data.RepeatType
import com.moidela.app.data.TaskEntity
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

val RU: Locale = Locale.forLanguageTag("ru")

fun LocalDate.fullTitle(): String =
    format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", RU)).replaceFirstChar { it.uppercase() }

fun LocalDate.shortDate(): String = format(DateTimeFormatter.ofPattern("dd.MM.yyyy", RU))

fun LocalDate.dayMonth(): String = format(DateTimeFormatter.ofPattern("d MMM", RU))

fun dayShort(d: DayOfWeek): String =
    d.getDisplayName(TextStyle.SHORT, RU).replaceFirstChar { it.uppercase() }

fun dayFull(d: DayOfWeek): String =
    d.getDisplayName(TextStyle.FULL_STANDALONE, RU).replaceFirstChar { it.uppercase() }

fun formatMinutes(m: Int): String = "%02d:%02d".format(m / 60, m % 60)

fun repeatSummary(t: TaskEntity): String? = when (t.repeatType) {
    RepeatType.NONE -> null
    RepeatType.DAILY -> "Каждый день"
    RepeatType.WEEKDAYS -> (0..6)
        .filter { ((t.weekdaysMask shr it) and 1) == 1 }
        .joinToString(", ") { dayShort(DayOfWeek.of(it + 1)) }
    RepeatType.INTERVAL ->
        if (t.intervalDays <= 1) "Каждый день" else "Каждые ${t.intervalDays} дн."
}
