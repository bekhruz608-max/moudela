package com.moidela.app.ui.main

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.moidela.app.data.SettingsRepository
import com.moidela.app.data.TaskRepository
import com.moidela.app.domain.DayItem
import com.moidela.app.domain.Schedule
import java.time.LocalDate
import java.util.Collections
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class TaskFilter(val label: String) {
    ALL("Все"), ACTIVE("Активные"), DONE("Выполненные"), FROZEN("Замороженные")
}

data class MainState(
    val day: LocalDate = LocalDate.now(),
    val filter: TaskFilter = TaskFilter.ALL,
    val items: List<DayItem> = emptyList(),
    val total: Int = 0,
    val done: Int = 0,
    val frozenCount: Int = 0,
    val weekDays: List<LocalDate> = emptyList()
)

class MainViewModel(
    private val repo: TaskRepository,
    settings: SettingsRepository
) : ViewModel() {

    private val day = MutableStateFlow(LocalDate.now())
    private val filter = MutableStateFlow(TaskFilter.ALL)
    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val messages = _messages.asSharedFlow()

    val state: StateFlow<MainState> = combine(
        repo.snapshot, settings.settings, day, filter
    ) { snap, st, date, flt ->
        val all = Schedule.forDay(date.toEpochDay(), snap.tasks, snap.done, snap.freezes)
        val active = all.filter { !it.frozen }
        val shown = when (flt) {
            TaskFilter.ALL -> active
            TaskFilter.ACTIVE -> active.filter { !it.done }
            TaskFilter.DONE -> active.filter { it.done }
            TaskFilter.FROZEN -> all.filter { it.frozen }
        }
        MainState(
            day = date,
            filter = flt,
            items = shown,
            total = active.size,
            done = active.count { it.done },
            frozenCount = all.size - active.size,
            weekDays = Schedule.weekOf(date, st.firstDay)
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MainState())

    fun selectDay(date: LocalDate) { day.value = date }
    fun shiftWeek(delta: Int) { day.value = day.value.plusWeeks(delta.toLong()) }
    fun goToday() { day.value = LocalDate.now() }
    fun setFilter(f: TaskFilter) { filter.value = f }

    private fun launchSafe(block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _messages.tryEmit("Не удалось выполнить действие. Попробуйте ещё раз.")
            }
        }
    }

    fun toggle(item: DayItem) = launchSafe {
        repo.setDone(item.task.id, day.value.toEpochDay(), !item.done)
    }

    fun moveToTomorrow(item: DayItem) {
        val epoch = day.value.toEpochDay()
        launchSafe {
            val ok = repo.moveToTomorrow(item.task.id, epoch)
            _messages.tryEmit(
                if (ok) "«${item.task.title}» перенесено на завтра"
                else "Это дело нельзя перенести"
            )
        }
    }

    fun delete(id: Long) = launchSafe {
        repo.delete(id)
        _messages.tryEmit("Дело удалено")
    }

    fun move(id: Long, up: Boolean) = launchSafe {
        val visible = state.value.items.map { it.task.id }
        val i = visible.indexOf(id)
        val j = if (up) i - 1 else i + 1
        if (i < 0 || j !in visible.indices) return@launchSafe
        val ids = repo.tasks.first().map { it.id }.toMutableList()
        val a = ids.indexOf(id)
        val b = ids.indexOf(visible[j])
        if (a < 0 || b < 0) return@launchSafe
        Collections.swap(ids, a, b)
        repo.reorder(ids)
    }
}
