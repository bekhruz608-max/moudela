package com.moidela.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import java.time.DayOfWeek
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

enum class ThemeMode { DARK, LIGHT, SYSTEM }

data class AppSettings(
    val theme: ThemeMode = ThemeMode.DARK,
    val firstDay: DayOfWeek = DayOfWeek.MONDAY,
    val remindersEnabled: Boolean = true
)

private val Context.dataStore by preferencesDataStore(name = "settings")

class SettingsRepository(private val context: Context) {
    private val themeKey = stringPreferencesKey("theme")
    private val firstDayKey = intPreferencesKey("first_day")
    private val remindersKey = booleanPreferencesKey("reminders")

    val settings: Flow<AppSettings> = context.dataStore.data
        .map { p ->
            AppSettings(
                theme = runCatching { ThemeMode.valueOf(p[themeKey] ?: "DARK") }
                    .getOrDefault(ThemeMode.DARK),
                firstDay = DayOfWeek.of((p[firstDayKey] ?: 1).coerceIn(1, 7)),
                remindersEnabled = p[remindersKey] ?: true
            )
        }
        .catch { emit(AppSettings()) }

    suspend fun setTheme(mode: ThemeMode) {
        context.dataStore.edit { it[themeKey] = mode.name }
    }

    suspend fun setFirstDay(day: DayOfWeek) {
        context.dataStore.edit { it[firstDayKey] = day.value }
    }

    suspend fun setReminders(enabled: Boolean) {
        context.dataStore.edit { it[remindersKey] = enabled }
    }
}
