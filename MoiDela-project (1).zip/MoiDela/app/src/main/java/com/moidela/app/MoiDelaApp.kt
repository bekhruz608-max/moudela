package com.moidela.app

import android.app.Application
import androidx.room.Room
import com.moidela.app.data.AppDatabase
import com.moidela.app.data.SettingsRepository
import com.moidela.app.data.TaskRepository
import com.moidela.app.notify.Reminders
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class MoiDelaApp : Application() {
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val database by lazy {
        Room.databaseBuilder(this, AppDatabase::class.java, "moidela.db").build()
    }
    val repository by lazy { TaskRepository(database) }
    val settings by lazy { SettingsRepository(this) }

    override fun onCreate() {
        super.onCreate()
        Reminders.ensureChannel(this)
        appScope.launch {
            var first = true
            combine(repository.snapshot, settings.settings) { snap, st -> snap to st }
                .collectLatest { (snap, st) ->
                    if (first) {
                        first = false
                        // Запуск процесса (в т.ч. после перезагрузки): показать пропущенное
                        Reminders.deliverDue(this@MoiDelaApp, snap, st)
                    } else {
                        Reminders.markNow(this@MoiDelaApp)
                    }
                    Reminders.schedule(this@MoiDelaApp, snap, st)
                }
        }
    }
}
