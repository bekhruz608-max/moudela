@file:OptIn(ExperimentalMaterial3Api::class)

package com.moidela.app.ui.edit

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.moidela.app.data.RepeatType
import com.moidela.app.ui.DatePickerDialogRu
import com.moidela.app.ui.TimePickerDialogRu
import com.moidela.app.ui.dayShort
import com.moidela.app.ui.formatMinutes
import com.moidela.app.ui.shortDate
import java.time.DayOfWeek

private val repeatOptions = listOf(
    RepeatType.NONE to "Без повтора",
    RepeatType.DAILY to "Каждый день",
    RepeatType.WEEKDAYS to "По дням недели",
    RepeatType.INTERVAL to "Через N дней"
)

@Composable
fun EditScreen(vm: EditViewModel, onBack: () -> Unit, onFreeze: () -> Unit) {
    var showDate by remember { mutableStateOf(false) }
    var showTime by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val scheme = MaterialTheme.colorScheme

    LaunchedEffect(vm.notFound) { if (vm.notFound) onBack() }

    Scaffold(
        containerColor = scheme.background,
        topBar = {
            TopAppBar(
                title = { Text(if (vm.isNew) "Новое дело" else "Редактирование") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
                    }
                },
                actions = {
                    if (!vm.isNew) {
                        IconButton(onClick = { confirmDelete = true }) {
                            Icon(Icons.Default.Delete, contentDescription = "Удалить", tint = scheme.error)
                        }
                    }
                }
            )
        },
        bottomBar = {
            Surface(color = scheme.background, modifier = Modifier.imePadding().navigationBarsPadding()) {
                Button(
                    onClick = { vm.save(onBack) },
                    enabled = !vm.saving && !vm.loading,
                    modifier = Modifier.fillMaxWidth().padding(16.dp).height(52.dp)
                ) { Text("Сохранить", style = MaterialTheme.typography.titleMedium) }
            }
        }
    ) { pad ->
        if (vm.loading) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            Column(
                Modifier
                    .padding(pad)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                OutlinedTextField(
                    value = vm.title,
                    onValueChange = { vm.title = it; vm.error = null },
                    label = { Text("Название") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.medium
                )
                OutlinedTextField(
                    value = vm.description,
                    onValueChange = { vm.description = it },
                    label = { Text("Описание") },
                    minLines = 3,
                    maxLines = 6,
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.medium
                )

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = { showDate = true },
                        modifier = Modifier.weight(1f).height(52.dp),
                        shape = MaterialTheme.shapes.medium
                    ) {
                        Icon(Icons.Default.Event, null, Modifier.size(18.dp))
                        Spacer(Modifier.size(8.dp))
                        Text(vm.date.shortDate())
                    }
                    OutlinedButton(
                        onClick = { showTime = true },
                        modifier = Modifier.weight(1f).height(52.dp),
                        shape = MaterialTheme.shapes.medium
                    ) {
                        Icon(Icons.Default.Schedule, null, Modifier.size(18.dp))
                        Spacer(Modifier.size(8.dp))
                        Text(vm.time?.let { formatMinutes(it.hour * 60 + it.minute) } ?: "Без времени")
                    }
                }
                if (vm.time != null) {
                    TextButton(onClick = { vm.time = null }) { Text("Убрать время") }
                }

                Text(
                    if (vm.time != null) "Напоминание придёт в это время"
                    else "Укажите время, чтобы получать напоминание",
                    style = MaterialTheme.typography.bodySmall,
                    color = scheme.onSurfaceVariant
                )

                Text("Повторение", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    repeatOptions.forEach { (type, label) ->
                        FilterChip(
                            selected = vm.repeat == type,
                            onClick = { vm.setRepeat(type) },
                            label = { Text(label) }
                        )
                    }
                }

                AnimatedVisibility(vm.repeat == RepeatType.WEEKDAYS) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        (0..6).forEach { i ->
                            val selected = ((vm.mask shr i) and 1) == 1
                            Box(
                                Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .clip(CircleShape)
                                    .background(if (selected) scheme.primary else scheme.surfaceVariant)
                                    .clickable { vm.toggleDay(i) },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    dayShort(DayOfWeek.of(i + 1)),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (selected) scheme.onPrimary else scheme.onSurface
                                )
                            }
                        }
                    }
                }
                AnimatedVisibility(vm.repeat == RepeatType.INTERVAL) {
                    OutlinedTextField(
                        value = vm.interval,
                        onValueChange = { v -> vm.interval = v.filter { it.isDigit() }.take(3); vm.error = null },
                        label = { Text("Повторять через каждые N дней") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        shape = MaterialTheme.shapes.medium
                    )
                }
                if (vm.repeat != RepeatType.NONE && !vm.isNew) {
                    Text(
                        "Изменения применяются ко всему повторяющемуся делу. Прошлые отметки выполнения сохраняются.",
                        style = MaterialTheme.typography.bodySmall,
                        color = scheme.onSurfaceVariant
                    )
                }

                vm.error?.let { Text(it, color = scheme.error, style = MaterialTheme.typography.bodyMedium) }

                if (!vm.isNew) {
                    OutlinedButton(
                        onClick = onFreeze,
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = MaterialTheme.shapes.medium
                    ) {
                        Icon(Icons.Default.AcUnit, null, Modifier.size(18.dp))
                        Spacer(Modifier.size(8.dp))
                        Text("Заморозка дела")
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    if (showDate) {
        DatePickerDialogRu(vm.date, { showDate = false }) { vm.date = it; showDate = false }
    }
    if (showTime) {
        TimePickerDialogRu(vm.time, { showTime = false }) { vm.time = it; showTime = false }
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Удалить дело?") },
            text = { Text("Дело, его отметки выполнения и периоды заморозки будут удалены без возможности восстановления.") },
            confirmButton = {
                TextButton(onClick = { confirmDelete = false; vm.delete(onBack) }) {
                    Text("Удалить", color = scheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Отмена") } }
        )
    }
}
