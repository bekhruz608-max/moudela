package com.moidela.app.data

import androidx.room.withTransaction
import com.moidela.app.domain.Recurrence
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

data class Snapshot(
    val tasks: List<TaskEntity>,
    val done: Set<Pair<Long, Long>>,
    val freezes: List<FreezeEntity>
)

class TaskRepository(private val db: AppDatabase) {
    private val dao = db.taskDao()

    val tasks: Flow<List<TaskEntity>> = dao.observeTasks()
    val freezes: Flow<List<FreezeEntity>> = dao.observeFreezes()

    val snapshot: Flow<Snapshot> = combine(
        dao.observeTasks(), dao.observeCompletions(), dao.observeFreezes()
    ) { t, c, f ->
        Snapshot(t, c.map { it.taskId to it.day }.toSet(), f)
    }

    suspend fun getTask(id: Long): TaskEntity? = dao.getTask(id)

    suspend fun save(task: TaskEntity): Long = db.withTransaction {
        if (task.id == 0L) {
            dao.insertTask(task.copy(sortOrder = dao.maxSort() + 1))
        } else {
            dao.updateTask(task)
            task.id
        }
    }

    suspend fun delete(id: Long) = dao.deleteTask(id)

    suspend fun setDone(taskId: Long, day: Long, done: Boolean) {
        if (done) dao.insertCompletion(CompletionEntity(taskId, day))
        else dao.deleteCompletion(taskId, day)
    }

    suspend fun reorder(orderedIds: List<Long>) = db.withTransaction {
        orderedIds.forEachIndexed { index, id -> dao.setSort(id, index.toLong()) }
    }

    suspend fun addFreeze(taskId: Long, start: Long, end: Long) {
        dao.insertFreeze(FreezeEntity(taskId = taskId, startDay = start, endDay = end))
    }

    suspend fun updateFreeze(freeze: FreezeEntity) = dao.updateFreeze(freeze)

    suspend fun deleteFreeze(id: Long) = dao.deleteFreeze(id)

    /**
     * «Перенести на завтра» для дела, которое отображается в день [day].
     *  - разовое дело: просто меняется дата;
     *  - повторяющееся, серия начинается в этот день: вся серия сдвигается на день вперёд;
     *  - повторяющееся, серия началась раньше: старая серия обрывается накануне,
     *    новая (сдвинутая на день) начинается завтра. Прошлые записи не меняются.
     * Повторный вызов для того же дня невозможен — дело в этот день уже не отображается,
     * поэтому дубликаты не создаются.
     */
    suspend fun moveToTomorrow(taskId: Long, day: Long): Boolean = db.withTransaction {
        val t = dao.getTask(taskId) ?: return@withTransaction false
        val freezes = dao.getFreezesFor(taskId)
        if (!Recurrence.occursOn(t, day)) return@withTransaction false
        if (Recurrence.isFrozen(freezes, taskId, day)) return@withTransaction false
        if (dao.doneCount(taskId, day) > 0) return@withTransaction false

        val next = day + 1
        if (t.repeatType == RepeatType.NONE) {
            dao.updateTask(t.copy(startDay = next))
            return@withTransaction true
        }

        val shifted = t.copy(
            startDay = next,
            endDay = t.endDay?.plus(1),
            weekdaysMask = Recurrence.rotateMask(t.weekdaysMask)
        )
        if (t.startDay >= day) {
            dao.updateTask(shifted)
        } else {
            val hadEarlier = (t.startDay until day).take(7).any { Recurrence.occursOn(t, it) }
            val newId = dao.insertTask(shifted.copy(id = 0))
            freezes.filter { it.endDay >= next }.forEach {
                dao.insertFreeze(
                    FreezeEntity(taskId = newId, startDay = maxOf(it.startDay, next), endDay = it.endDay)
                )
            }
            if (hadEarlier) dao.updateTask(t.copy(endDay = day - 1)) else dao.deleteTask(t.id)
        }
        true
    }
}
